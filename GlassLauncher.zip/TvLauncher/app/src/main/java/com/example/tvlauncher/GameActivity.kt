package com.example.tvlauncher

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import kotlin.random.Random

class GameActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(Snake(this))
    }
}

/** Retro Snake: D-pad to steer, OK to restart, Back to exit. Runs ~8 fps, nearly zero load. */
class Snake(c: Context) : View(c) {
    private val n = 24
    private val body = ArrayDeque<Int>()
    private var dir = 1 // 0 up, 1 right, 2 down, 3 left
    private var food = 0
    private var alive = true
    private var score = 0
    private val p = Paint()
    private val tick = object : Runnable {
        override fun run() { step(); invalidate(); postDelayed(this, 120) }
    }

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        requestFocus()
        reset()
        post(tick)
    }

    private fun reset() {
        body.clear(); body.addLast(n * n / 2 + n / 2)
        dir = 1; alive = true; score = 0; food = Random.nextInt(n * n)
    }

    private fun step() {
        if (!alive) return
        val head = body.last()
        var x = head % n
        var y = head / n
        when (dir) { 0 -> y--; 1 -> x++; 2 -> y++; else -> x-- }
        val cell = y * n + x
        if (x < 0 || y < 0 || x >= n || y >= n || body.contains(cell)) { alive = false; return }
        body.addLast(cell)
        if (cell == food) { score++; food = Random.nextInt(n * n) } else body.removeFirst()
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.BLACK)
        val cs = minOf(width, height) / n
        val ox = (width - cs * n) / 2f
        val oy = (height - cs * n) / 2f
        p.color = 0xFF14202B.toInt()
        canvas.drawRect(ox, oy, ox + cs * n, oy + cs * n, p)
        p.color = Color.RED
        canvas.drawRect(ox + food % n * cs, oy + food / n * cs, ox + (food % n + 1) * cs, oy + (food / n + 1) * cs, p)
        p.color = 0xFF4CD964.toInt()
        for (b in body) canvas.drawRect(ox + b % n * cs + 1, oy + b / n * cs + 1, ox + (b % n + 1) * cs - 1, oy + (b / n + 1) * cs - 1, p)
        p.color = Color.WHITE
        p.textSize = cs * 1.1f
        canvas.drawText("Score $score" + if (alive) "" else "  -  Game over, press OK", ox, oy - cs * 0.3f, p)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> if (dir != 2) dir = 0
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (dir != 3) dir = 1
            KeyEvent.KEYCODE_DPAD_DOWN -> if (dir != 0) dir = 2
            KeyEvent.KEYCODE_DPAD_LEFT -> if (dir != 1) dir = 3
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> if (!alive) reset()
            else -> return super.onKeyDown(keyCode, event)
        }
        return true
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }
}
