package com.example.tvlauncher

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.net.NetworkInterface
import kotlin.random.Random

class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var pm: PackageManager
    private lateinit var prefs: SharedPreferences
    private lateinit var side: LinearLayout
    private lateinit var allApps: RecyclerView
    private lateinit var ambient: TextClock
    private lateinit var volPill: LinearLayout
    private lateinit var volBar: ProgressBar
    private lateinit var firstFocus: View
    private var server: RemoteServer? = null

    private val hideVol = Runnable { volPill.visibility = View.GONE }
    private val idle = Runnable {
        // Ambient (AOD-style) clock; random offset each time avoids screen burn-in.
        ambient.setPadding(dp(Random.nextInt(0, 300)), dp(Random.nextInt(0, 200)), 0, 0)
        ambient.visibility = View.VISIBLE
    }
    private val defaultPins = setOf("com.netflix.ninja", "com.amazon.amazonvideo.livingroom", "com.spotify.tv.android")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_LONG).show()

    // ---------- UI building blocks ----------
    private fun tv(t: String, sp: Float): TextView {
        val v = TextView(this); v.text = t; v.textSize = sp; v.setTextColor(Color.WHITE); return v
    }

    private fun emoji(t: String, sp: Float): TextView {
        val v = tv(t, sp); v.gravity = Gravity.CENTER; return v
    }

    /** "Liquid glass" without blur (blur is too heavy for 2GB TVs): translucent fill + bright rim. */
    private fun glass(r: Int): StateListDrawable {
        fun s(fill: Int, stroke: Int) = GradientDrawable().apply {
            cornerRadius = dp(r).toFloat(); setColor(fill); setStroke(dp(2), stroke)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), s(0x55FFFFFF, 0xFFFFFFFF.toInt()))
            addState(intArrayOf(), s(0x26FFFFFF, 0x33FFFFFF))
        }
    }

    private fun tile(icon: View, label: String, w: Int, onClick: () -> Unit, onLong: (() -> Unit)? = null): View {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.setPadding(dp(10), dp(12), dp(10), dp(12))
        t.background = glass(20)
        t.isFocusable = true
        t.isClickable = true
        t.contentDescription = label // accessibility / TalkBack
        t.addView(icon)
        val l = tv(label, 13f)
        l.gravity = Gravity.CENTER; l.maxLines = 1; l.ellipsize = TextUtils.TruncateAt.END
        t.addView(l, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(6) })
        t.layoutParams = LinearLayout.LayoutParams(dp(w), WRAP_CONTENT).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }
        t.setOnClickListener { onClick() }
        if (onLong != null) t.setOnLongClickListener { onLong(); true }
        t.setOnFocusChangeListener { v, f ->
            val s = if (f) 1.08f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
        return t
    }

    private fun installed(p: String) = try { pm.getApplicationInfo(p, 0); true } catch (e: Exception) { false }
    private fun appLabel(p: String) = try { pm.getApplicationLabel(pm.getApplicationInfo(p, 0)).toString() } catch (e: Exception) { p }

    private fun iconFor(pkgs: List<String>, fallback: String): View {
        for (p in pkgs) {
            try {
                val iv = ImageView(this)
                iv.setImageDrawable(pm.getApplicationIcon(p))
                iv.layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
                return iv
            } catch (e: Exception) {}
        }
        return emoji(fallback, 34f)
    }

    /** Tries TV launch intent first, then the normal one, so apps without TV support still open. */
    private fun launchAny(name: String, pkgs: List<String>) {
        for (p in pkgs) {
            val i = pm.getLeanbackLaunchIntentForPackage(p) ?: pm.getLaunchIntentForPackage(p)
            if (i != null) { startActivity(i); return }
        }
        toast("$name is not installed")
    }

    // ---------- Screen ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pm = packageManager
        prefs = getSharedPreferences("launcher", MODE_PRIVATE)

        val root = FrameLayout(this)
        root.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF0F2027.toInt(), 0xFF2C5364.toInt(), 0xFF4B2A6B.toInt())
        )
        val row = LinearLayout(this)
        side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_VERTICAL
        side.setPadding(dp(14), dp(24), dp(6), dp(24))
        row.addView(side, LinearLayout.LayoutParams(dp(120), MATCH_PARENT))

        val main = LinearLayout(this)
        main.orientation = LinearLayout.VERTICAL
        main.setPadding(dp(20), dp(24), dp(40), dp(24))

        // Top bar: clock + quick toggles
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val clock = TextClock(this)
        clock.format12Hour = "h:mm a"; clock.format24Hour = "HH:mm"
        clock.textSize = 40f; clock.setTextColor(Color.WHITE)
        top.addView(clock, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        top.addView(tile(emoji("\uD83D\uDCF6", 26f), "Wi-Fi", 84, { toggleWifi() }))
        top.addView(tile(emoji("\uD83D\uDD35", 26f), "Bluetooth", 96, { toggleBt() }, { openBtSettings() }))
        top.addView(tile(emoji("\uD83C\uDFA4", 26f), "Voice", 84, { voice() }))
        top.addView(tile(emoji("\uD83D\uDCF1", 26f), "Phone remote", 120, { toggleRemote() }))
        main.addView(top, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))

        // Games
        val games = LinearLayout(this)
        games.gravity = Gravity.CENTER
        firstFocus = tile(emoji("\uD83D\uDD79\uFE0F", 48f), "Retro Arcade", 240, {
            startActivity(Intent(this, GameActivity::class.java))
        })
        games.addView(firstFocus)
        games.addView(tile(emoji("\u2601\uFE0F", 48f), "Cloud Gaming", 240, { openCloud() }))
        main.addView(games, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        // Dock: one tap access
        val dock = LinearLayout(this)
        dock.gravity = Gravity.CENTER
        dock.setPadding(dp(12), dp(8), dp(12), dp(8))
        dock.background = glass(32)
        val yt = listOf("com.google.android.youtube.tv", "com.google.android.youtube")
        val hs = listOf("in.startv.hotstar.dplus.tv", "in.startv.hotstar", "in.startv.hotstar.dplus")
        val ch = listOf("com.android.chrome")
        dock.addView(tile(iconFor(yt, "\u25B6\uFE0F"), "YouTube", 120, { launchAny("YouTube", yt) }))
        dock.addView(tile(iconFor(hs, "\u2B50"), "JioHotstar", 120, { launchAny("JioHotstar", hs) }))
        dock.addView(tile(iconFor(ch, "\uD83C\uDF10"), "Chrome", 120, { launchAny("Chrome", ch) }))
        dock.addView(tile(emoji("\u2699\uFE0F", 34f), "Settings", 120, {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) { toast("Settings unavailable") }
        }))
        dock.addView(tile(emoji("\u2630", 34f), "All apps", 120, { showApps(true) }))
        main.addView(dock, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        row.addView(main, LinearLayout.LayoutParams(0, MATCH_PARENT, 1f))
        root.addView(row, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // All apps overlay
        allApps = RecyclerView(this)
        allApps.layoutManager = GridLayoutManager(this, 5)
        allApps.setHasFixedSize(true)
        allApps.setBackgroundColor(0xF0101820.toInt())
        allApps.setPadding(dp(48), dp(48), dp(48), dp(48))
        allApps.clipToPadding = false
        allApps.visibility = View.GONE
        root.addView(allApps, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        // iPhone-style volume pill
        volBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        volPill = LinearLayout(this)
        volPill.gravity = Gravity.CENTER_VERTICAL
        volPill.setPadding(dp(18), dp(12), dp(18), dp(12))
        volPill.background = glass(30)
        volPill.visibility = View.GONE
        volPill.addView(tv("\uD83D\uDD0A", 20f))
        volPill.addView(volBar, LinearLayout.LayoutParams(dp(180), WRAP_CONTENT).apply { leftMargin = dp(12) })
        root.addView(volPill, FrameLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT, Gravity.TOP or Gravity.END).apply {
            setMargins(0, dp(24), dp(40), 0)
        })

        // Ambient clock (shown after 2 min idle)
        ambient = TextClock(this)
        ambient.format12Hour = "h:mm"; ambient.format24Hour = "HH:mm"
        ambient.textSize = 96f; ambient.setTextColor(0xFF9AA4B2.toInt())
        ambient.gravity = Gravity.CENTER
        ambient.setBackgroundColor(Color.BLACK)
        ambient.visibility = View.GONE
        root.addView(ambient, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        rebuildSidebar()
        h.removeCallbacks(idle); h.postDelayed(idle, 120_000)
        if (allApps.visibility != View.VISIBLE) firstFocus.post { firstFocus.requestFocus() }
    }

    override fun onPause() {
        h.removeCallbacks(idle)
        super.onPause()
    }

    override fun onDestroy() {
        server?.shutdown()
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        showApps(false) // Home button returns to the home screen
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (allApps.visibility == View.VISIBLE) showApps(false) // launcher never exits
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        h.removeCallbacks(idle); h.postDelayed(idle, 120_000)
        if (ambient.visibility == View.VISIBLE) {
            if (e.action == KeyEvent.ACTION_UP) ambient.visibility = View.GONE
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            adjustVol(keyCode == KeyEvent.KEYCODE_VOLUME_UP)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    // ---------- Features ----------
    private fun adjustVol(up: Boolean) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, 0)
        volBar.max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        volBar.progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        volPill.visibility = View.VISIBLE
        h.removeCallbacks(hideVol); h.postDelayed(hideVol, 1500)
    }

    @Suppress("DEPRECATION")
    private fun toggleWifi() {
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val on = !wm.isWifiEnabled
            wm.isWifiEnabled = on
            toast("Wi-Fi " + if (on) "on" else "off")
        } catch (e: Exception) { toast("Could not change Wi-Fi") }
    }

    @Suppress("DEPRECATION", "MissingPermission")
    private fun toggleBt() {
        val bt = BluetoothAdapter.getDefaultAdapter()
        if (bt == null) { toast("No Bluetooth hardware detected on this TV"); return }
        try {
            val on = !bt.isEnabled
            if (on) bt.enable() else bt.disable()
            toast("Bluetooth turning " + if (on) "on" else "off")
        } catch (e: Exception) { toast("Could not change Bluetooth") }
    }

    private fun openBtSettings() {
        try { startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)) } catch (e: Exception) { toast("Bluetooth settings not available on this TV") }
    }

    private fun voice() {
        try { startActivity(Intent(Intent.ACTION_VOICE_COMMAND)) } catch (e: Exception) { toast("No voice assistant found on this TV") }
    }

    private fun openCloud() {
        val pkg = "com.nvidia.geforcenow"
        val i = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
        try { startActivity(i ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://play.geforcenow.com"))) }
        catch (e: Exception) { toast("Install a browser or GeForce NOW first") }
    }

    private fun toggleRemote() {
        if (server != null) { server?.shutdown(); server = null; toast("Phone remote off"); return }
        val ip = NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && (it.hostAddress ?: ":").indexOf(':') < 0 }?.hostAddress ?: "?"
        server = RemoteServer { remoteKey(it) }.also { it.start() }
        toast("Phone remote on. On your phone (same Wi-Fi) open http://$ip:8080")
    }

    private fun remoteKey(k: String) = runOnUiThread {
        val code = when (k) {
            "up" -> KeyEvent.KEYCODE_DPAD_UP
            "down" -> KeyEvent.KEYCODE_DPAD_DOWN
            "left" -> KeyEvent.KEYCODE_DPAD_LEFT
            "right" -> KeyEvent.KEYCODE_DPAD_RIGHT
            "ok" -> KeyEvent.KEYCODE_DPAD_CENTER
            "back" -> { onBackPressed(); return@runOnUiThread }
            "vup" -> { adjustVol(true); return@runOnUiThread }
            "vdown" -> { adjustVol(false); return@runOnUiThread }
            else -> return@runOnUiThread
        }
        dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        dispatchKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun rebuildSidebar() {
        side.removeAllViews()
        prefs.getStringSet("pins", defaultPins)!!.filter { installed(it) }.sortedBy { appLabel(it) }.forEach { p ->
            side.addView(tile(iconFor(listOf(p), "\u25B6"), appLabel(p), 92, { launchAny(appLabel(p), listOf(p)) }, { togglePin(p) }))
        }
    }

    private fun togglePin(p: String) {
        val s = HashSet(prefs.getStringSet("pins", defaultPins)!!)
        val added = s.add(p)
        if (!added) s.remove(p)
        prefs.edit().putStringSet("pins", s).apply()
        rebuildSidebar()
        toast(if (added) "Pinned to sidebar" else "Removed from sidebar")
    }

    private fun showApps(show: Boolean) {
        if (!show) {
            allApps.visibility = View.GONE
            allApps.adapter = null // free memory
            return
        }
        val q1 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        val q2 = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val list = (pm.queryIntentActivities(q1, 0) + pm.queryIntentActivities(q2, 0))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        allApps.adapter = AppAdapter(list, pm,
            { a -> launchAny(a.loadLabel(pm).toString(), listOf(a.activityInfo.packageName)) },
            { a -> togglePin(a.activityInfo.packageName) })
        allApps.visibility = View.VISIBLE
        allApps.post { allApps.getChildAt(0)?.requestFocus() }
    }
}

class AppAdapter(
    private val apps: List<ResolveInfo>,
    private val pm: PackageManager,
    private val onClick: (ResolveInfo) -> Unit,
    private val onLong: (ResolveInfo) -> Unit
) : RecyclerView.Adapter<AppAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val icon: ImageView = v.findViewById(R.id.icon)
        val label: TextView = v.findViewById(R.id.label)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun onBindViewHolder(h: VH, position: Int) {
        val app = apps[position]
        h.icon.setImageDrawable(app.activityInfo.loadBanner(pm) ?: app.loadIcon(pm))
        h.label.text = app.loadLabel(pm)
        h.itemView.contentDescription = h.label.text
        h.itemView.setOnClickListener { onClick(app) }
        h.itemView.setOnLongClickListener { onLong(app); true }
        h.itemView.setOnFocusChangeListener { v, focused ->
            val s = if (focused) 1.1f else 1f
            v.animate().scaleX(s).scaleY(s).setDuration(120).start()
        }
    }

    override fun getItemCount() = apps.size
}
