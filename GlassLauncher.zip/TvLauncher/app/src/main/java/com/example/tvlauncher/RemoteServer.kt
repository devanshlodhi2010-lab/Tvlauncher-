package com.example.tvlauncher

import java.net.ServerSocket

/** Tiny HTTP server (no libraries). Phone opens http://TV-IP:8080 and taps buttons. */
class RemoteServer(private val onKey: (String) -> Unit) : Thread() {
    private var ss: ServerSocket? = null
    @Volatile private var alive = true

    override fun run() {
        try {
            ss = ServerSocket(8080)
            while (alive) {
                val s = ss!!.accept()
                try {
                    val line = s.getInputStream().bufferedReader().readLine() ?: ""
                    val path = line.split(" ").getOrElse(1) { "/" }
                    val isKey = path.startsWith("/k/")
                    if (isKey) onKey(path.substring(3))
                    val b = (if (isKey) "ok" else PAGE).toByteArray()
                    val o = s.getOutputStream()
                    o.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.size + "\r\nConnection: close\r\n\r\n").toByteArray())
                    o.write(b)
                    o.flush()
                } catch (e: Exception) {
                } finally {
                    s.close()
                }
            }
        } catch (e: Exception) {
        }
    }

    fun shutdown() {
        alive = false
        try { ss?.close() } catch (e: Exception) {}
    }

    companion object {
        const val PAGE = """<meta name=viewport content="width=device-width"><style>body{font:22px sans-serif;background:#111;color:#fff;text-align:center}button{width:30%;height:70px;margin:4px;font-size:24px;border-radius:16px;border:0}</style><div><button onclick=k('up')>&#9650;</button></div><div><button onclick=k('left')>&#9664;</button><button onclick=k('ok')>OK</button><button onclick=k('right')>&#9654;</button></div><div><button onclick=k('down')>&#9660;</button></div><div><button onclick=k('back')>Back</button><button onclick=k('vup')>Vol+</button><button onclick=k('vdown')>Vol-</button></div><script>function k(x){fetch('/k/'+x)}</script>"""
    }
}
